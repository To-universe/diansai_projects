#include "ADC_Sample.h"
#include "adc.h"
#include "main.h"
#include "stm32g4xx_hal_adc.h"
#include "stm32g4xx_hal_def.h"
#include "stm32g4xx_hal_tim.h"
#include "tim.h"
#include <stdint.h>

uint16_t adc_buffer[ADC_SIZE];
uint8_t adc_finish_flag = 0;

void ADC_Start(void){
    if(HAL_ADC_Start_DMA(&hadc1, (uint32_t*)adc_buffer,ADC_SIZE) != HAL_OK){
        Error_Handler();
    }
    if(HAL_TIM_Base_Start(&htim3) != HAL_OK){
        Error_Handler();
    }
}

void ADC_Stop(void){
    HAL_TIM_Base_Stop(&htim3);
    HAL_ADC_Stop_DMA(&hadc1);
}

