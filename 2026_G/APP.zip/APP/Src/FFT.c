#include "FFT.h"
#include "ADC_Sample.h"
#include "FPGA_CTRL.h"
#include "arm_math.h"
#include "arm_math_types.h"
#include "dsp/basic_math_functions.h"
#include "dsp/statistics_functions.h"
#include "dsp/transform_functions.h"
#include "hanning_window_q15.h"
#include <math.h>
#include <stdint.h>


arm_rfft_instance_q15 fft_instance;
q15_t fft_input[FFT_SIZE];
q15_t fft_output[FFT_SIZE * 2];
float32_t magnitude[FFT_SIZE/2];
float32_t noise_lim;
uint16_t peak_bin[PEAK_MAX_COUNT];uint8_t peak_count=0;
float32_t peak_bin_freq[PEAK_MAX_COUNT];
float32_t peak_interp_freq[PEAK_MAX_COUNT];

float32_t fitted_f0;
float32_t measured_f0;
uint8_t peak_harmonic_order[PEAK_MAX_COUNT];
float32_t fitted_peak_freq[PEAK_MAX_COUNT];

//ADC格式转换为Q15
void adc_to_q15(uint16_t * adc_data,q15_t * fft_data){
    uint32_t sum = 0U;
    for(uint16_t i = 0 ;i<FFT_SIZE;i++){
        sum += adc_data[i];
    }
    int32_t mean = (int32_t)(sum/FFT_SIZE);

    for(uint16_t i = 0;i<FFT_SIZE;i++){
        int32_t centered = (int32_t)adc_data[i]-mean;

        int32_t q15_value = centered << 4;
        if(q15_value > 32767){
            q15_value = 32767;
        }else if(q15_value < -32768){
            q15_value = -32768;
        }

        fft_data[i] = q15_value;
    }
}
//计算幅度谱（未回归真实幅值）
void get_mag(void){
    for(uint16_t i = 0;i<FFT_SIZE/2;i++){
        if(i == 0){
            magnitude[i]=(float32_t)fft_output[0];
            continue;
        }else{
            float32_t real = (float32_t)fft_output[2*i];
            float32_t imag = (float32_t)fft_output[2*i+1];
            magnitude[i] = sqrtf(real * real + imag * imag);
        }
    }
}
//计算噪声门限
void get_noise_lim(void){
    float32_t mean;
    arm_mean_f32(magnitude, FFT_SIZE/2, &mean);
    noise_lim = mean * 4.0f;
}

static float32_t interp_peak_freq(uint16_t bin)
{
    if(bin == 0U || bin >= (FFT_SIZE / 2U - 1U)){
        return (float32_t)bin * FS / (float32_t)FFT_SIZE;
    }

    float32_t ym1 = magnitude[bin - 1U];
    float32_t y0 = magnitude[bin];
    float32_t yp1 = magnitude[bin + 1U];

    if(ym1 <= 0.0f || y0 <= 0.0f || yp1 <= 0.0f){
        return (float32_t)bin * FS / (float32_t)FFT_SIZE;
    }

    ym1 = logf(ym1);
    y0 = logf(y0);
    yp1 = logf(yp1);

    float32_t denom = ym1 - 2.0f * y0 + yp1;
    if(fabsf(denom) < 1.0e-12f){
        return (float32_t)bin * FS / (float32_t)FFT_SIZE;
    }

    float32_t delta = 0.5f * (ym1 - yp1) / denom;
    if(delta > 0.5f){
        delta = 0.5f;
    }else if(delta < -0.5f){
        delta = -0.5f;
    }

    return ((float32_t)bin + delta) * FS / (float32_t)FFT_SIZE;
}

//获取峰值频点
void find_peak_bin(void){
    peak_count = 0;
    for(uint16_t i = BIN_MIN;i<=BIN_MAX;i++){
        if(magnitude[i] > magnitude[i-1] &&
            magnitude[i] > magnitude[i+1] && 
            magnitude[i]>noise_lim
        ){
            peak_bin[peak_count] = i;
            peak_bin_freq[peak_count] = (float32_t)i * FS / (float32_t)FFT_SIZE;
            peak_interp_freq[peak_count] = interp_peak_freq(i);
            peak_count ++;
        }

        if(peak_count==PEAK_MAX_COUNT){
            break;
        }
    }
}

static float32_t abs_f32(float32_t x){
    return x >= 0.0f ? x : -x;
}

static int32_t round_to_int(float32_t x)
{
    return (int32_t)(x + 0.5f);
}

//拟合得到最可能频率（500Hz整倍数）
void fit_fundamental_freq(void){
    if(peak_count == 0){
        fitted_f0 = 0.0f;
        measured_f0 = 0.0f;
        return;
    }

    int32_t g0 = round_to_int(peak_interp_freq[0]/FREQ_GRID_HZ);
    float32_t best_score = 1e12f;
    int32_t best_g = 0;
    for(int32_t g = g0 - FUND_SEARCH_RADIUS;g <= g0 + FUND_SEARCH_RADIUS;g++){
        if(g < G_MIN || g > G_MAX){
            continue;
        }
        float32_t f0 = (float32_t)g*FREQ_GRID_HZ;
        float32_t score = abs_f32(peak_interp_freq[0] - f0) * 2.0f;
        
        for (uint8_t i = 1; i < peak_count; i++) {
            int32_t n = round_to_int(peak_interp_freq[i] / f0);
            if (n < 2 || n > 20) {
                score += 1e12f;
                continue;
            }

            float32_t expected = (float32_t)n * f0;
            score += abs_f32(peak_interp_freq[i] - expected);
        }

        if(score < best_score){
            best_score = score;
            best_g = g;
        }
    }
    fitted_f0 = (float32_t)best_g * FREQ_GRID_HZ;

    peak_harmonic_order[0] = 1;
    fitted_peak_freq[0] = fitted_f0;

    for(uint8_t i = 1;i<peak_count;i++){
        int32_t n = round_to_int(peak_interp_freq[i]/fitted_f0);
        peak_harmonic_order[i] = (uint8_t)n;
        fitted_peak_freq[i] = (float32_t)n * fitted_f0;
    }

    float32_t weighted_f0_sum = 0.0f;
    float32_t weight_sum = 0.0f;
    for(uint8_t i = 0;i<peak_count;i++){
        uint8_t order = peak_harmonic_order[i];
        if(order == 0U){
            continue;
        }

        float32_t weight = magnitude[peak_bin[i]];
        weighted_f0_sum += weight * peak_interp_freq[i] / (float32_t)order;
        weight_sum += weight;
    }

    measured_f0 = fitted_f0;
    if(weight_sum > 0.0f){
        measured_f0 = weighted_f0_sum / weight_sum;
    }

}

//单次FFT计算API
void fft_calc(void){
    arm_rfft_init_4096_q15(&fft_instance,0U,1U);
    // adc_to_q15(adc_buffer, fft_input);
    q15_t mean;
    arm_mean_q15(FPGA_buffer, FFT_SIZE, &mean);
    arm_offset_q15(FPGA_buffer, -mean, FPGA_buffer, FFT_SIZE);
    arm_mult_q15(FPGA_buffer, hanning_window_q15_4096,FPGA_buffer, FFT_SIZE);
    arm_rfft_q15(&fft_instance,FPGA_buffer,fft_output);
    get_mag();
    get_noise_lim();
    find_peak_bin();
    fit_fundamental_freq();
}

