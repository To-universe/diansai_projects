#include "Vol_calc.h"
#include "ADC_Sample.h"
#include "app_main.h"
#include "arm_math_types.h"
#include <math.h>
#include <stdint.h>
#include "FFT.h"
#include "dsp/fast_math_functions.h"

#define VPP_RECON_SIZE 1024U
#define LS_MAX_DIM (1U + 2U * PEAK_MAX_COUNT)

float32_t adc_max = 0.0f;
float32_t adc_min = 4095.0f;

static void clear_amp_by_order(float32_t* vol_amp_by_order)
{
    if(vol_amp_by_order == NULL){
        return;
    }

    for(uint8_t i = 0U; i < VOL_AMP_BY_ORDER_SIZE; i++){
        vol_amp_by_order[i] = 0.0f;
    }
}

static uint8_t solve_linear_system(float32_t a[LS_MAX_DIM][LS_MAX_DIM],
                                   float32_t b[LS_MAX_DIM],
                                   float32_t x[LS_MAX_DIM],
                                   uint8_t dim)
{
    for(uint8_t i = 0U; i < dim; i++){
        uint8_t pivot = i;
        float32_t max_abs = fabsf(a[i][i]);

        for(uint8_t r = (uint8_t)(i + 1U); r < dim; r++){
            float32_t v = fabsf(a[r][i]);
            if(v > max_abs){
                max_abs = v;
                pivot = r;
            }
        }

        if(max_abs < 1.0e-9f){
            return 0U;
        }

        if(pivot != i){
            for(uint8_t c = i; c < dim; c++){
                float32_t tmp = a[i][c];
                a[i][c] = a[pivot][c];
                a[pivot][c] = tmp;
            }

            float32_t tmp_b = b[i];
            b[i] = b[pivot];
            b[pivot] = tmp_b;
        }

        float32_t pivot_value = a[i][i];
        for(uint8_t r = (uint8_t)(i + 1U); r < dim; r++){
            float32_t factor = a[r][i] / pivot_value;
            a[r][i] = 0.0f;

            for(uint8_t c = (uint8_t)(i + 1U); c < dim; c++){
                a[r][c] -= factor * a[i][c];
            }
            b[r] -= factor * b[i];
        }
    }

    for(int32_t i = (int32_t)dim - 1; i >= 0; i--){
        float32_t sum = b[i];
        for(uint8_t c = (uint8_t)(i + 1); c < dim; c++){
            sum -= a[i][c] * x[c];
        }
        x[i] = sum / a[i][i];
    }

    return 1U;
}

float32_t calc_vrms(void){
    float32_t mean=0.0f;

    for(uint16_t i = 0 ; i < METRIC_SIZE ;i++){
        mean += (float32_t)adc_buffer[i];
    }

    mean /= METRIC_SIZE;
    float32_t sum_sq = 0.0f;
    for(uint16_t i = 0; i< METRIC_SIZE ;i++){
        float32_t v = ((float32_t)adc_buffer[i]-mean) * ADC_VREF / ADC_FULL_SCALE;
        v *= INPUT_SCALE;
        sum_sq += v*v;
    }
    return sqrtf(sum_sq/METRIC_SIZE);
}

float32_t calc_vpp(void){
    const float32_t adc_to_volt = ADC_VREF * INPUT_SCALE / ADC_FULL_SCALE;

    if(peak_count == 0U || fitted_f0 <= 0.0f){
        return 0.0f;
    }

    float32_t I[PEAK_MAX_COUNT]={0};
    float32_t Q[PEAK_MAX_COUNT]={0};
    uint8_t order_list[PEAK_MAX_COUNT]={0};
    uint8_t component_count = 0U;
    uint8_t peak_limit = peak_count;
    if(peak_limit > PEAK_MAX_COUNT){
        peak_limit = PEAK_MAX_COUNT;
    }

    for(uint8_t i = 0U; i < peak_limit; i++){
        uint8_t order = peak_harmonic_order[i];
        if(order > 0U){
            order_list[component_count] = order;
            component_count++;
        }
    }

    if(component_count == 0U){
        return 0.0f;
    }

    float32_t f0_for_fit = measured_f0;
    if(f0_for_fit <= 0.0f){
        f0_for_fit = fitted_f0;
    }

    uint8_t dim = (uint8_t)(1U + 2U * component_count);
    float32_t normal[LS_MAX_DIM][LS_MAX_DIM] = {{0.0f}};
    float32_t rhs[LS_MAX_DIM] = {0.0f};
    float32_t coef[LS_MAX_DIM] = {0.0f};
    float32_t row[LS_MAX_DIM] = {0.0f};
    float32_t base_phase_step = 2.0f * PI * f0_for_fit / FS;

    for(uint16_t j = 0U; j < METRIC_SIZE; j++){
        float32_t v = (float32_t)adc_buffer[j] * adc_to_volt;
        float32_t base_phase = base_phase_step * (float32_t)j;

        row[0] = 1.0f;
        for(uint8_t i = 0U; i < component_count; i++){
            float32_t phase = base_phase * (float32_t)order_list[i];
            row[1U + 2U * i] = arm_cos_f32(phase);
            row[2U + 2U * i] = arm_sin_f32(phase);
        }

        for(uint8_t r = 0U; r < dim; r++){
            rhs[r] += row[r] * v;
            for(uint8_t c = 0U; c < dim; c++){
                normal[r][c] += row[r] * row[c];
            }
        }
    }

    if(!solve_linear_system(normal, rhs, coef, dim)){
        return 0.0f;
    }

    for(uint8_t i = 0U; i < component_count; i++){
        I[i] = coef[1U + 2U * i];
        Q[i] = coef[2U + 2U * i];
    }

    float32_t max_v =-1e9f;
    float32_t min_v = 1e9f;

    for(uint16_t k =0U;k < VPP_RECON_SIZE;k++){
        float32_t x = 0.0f;
        float32_t theta = 2.0f * PI * (float32_t)k / (float32_t)VPP_RECON_SIZE;

        for(uint8_t i = 0 ;i < component_count;i++){
            uint8_t order = order_list[i];
            float32_t phase = theta * (float32_t)order;
            x += I[i] * arm_cos_f32(phase) + Q[i] * arm_sin_f32(phase);
        }

        if(x >max_v){max_v = x;}
        if(x<min_v){min_v = x;}
    }
    float32_t v_pp;
    v_pp = max_v-min_v;
    (void)v_pp;
    return max_v-min_v;
}


void calc_Vol(float32_t* Vrms,float32_t* Vpp,float32_t* vol_amp_by_order){
    const float32_t adc_to_volt = ADC_VREF * INPUT_SCALE / ADC_FULL_SCALE;
    clear_amp_by_order(vol_amp_by_order);

    if(peak_count == 0U || fitted_f0 <= 0.0f){
        *Vrms = 0.0f;
        *Vpp = 0.0f;
        return;
    }

    float32_t I[PEAK_MAX_COUNT]={0};
    float32_t Q[PEAK_MAX_COUNT]={0};
    uint8_t order_list[PEAK_MAX_COUNT]={0};
    uint8_t component_count = 0U;
    uint8_t peak_limit = peak_count;
    if(peak_limit > PEAK_MAX_COUNT){
        peak_limit = PEAK_MAX_COUNT;
    }

    for(uint8_t i = 0U; i < peak_limit; i++){
        uint8_t order = peak_harmonic_order[i];
        if(order > 0U){
            order_list[component_count] = order;
            component_count++;
        }
    }

    if(component_count == 0U){
        *Vrms = 0.0f;
        *Vpp = 0.0f;
        return;
    }

    float32_t f0_for_fit = measured_f0;
    if(f0_for_fit <= 0.0f){
        f0_for_fit = fitted_f0;
    }

    uint8_t dim = (uint8_t)(1U + 2U * component_count);
    float32_t normal[LS_MAX_DIM][LS_MAX_DIM] = {{0.0f}};
    float32_t rhs[LS_MAX_DIM] = {0.0f};
    float32_t coef[LS_MAX_DIM] = {0.0f};
    float32_t row[LS_MAX_DIM] = {0.0f};
    float32_t base_phase_step = 2.0f * PI * f0_for_fit / FS;

    for(uint16_t j = 0U; j < METRIC_SIZE; j++){
        float32_t v = (float32_t)adc_buffer[j] * adc_to_volt;
        float32_t base_phase = base_phase_step * (float32_t)j;

        row[0] = 1.0f;
        for(uint8_t i = 0U; i < component_count; i++){
            float32_t phase = base_phase * (float32_t)order_list[i];
            row[1U + 2U * i] = arm_cos_f32(phase);
            row[2U + 2U * i] = arm_sin_f32(phase);
        }

        for(uint8_t r = 0U; r < dim; r++){
            rhs[r] += row[r] * v;
            for(uint8_t c = 0U; c < dim; c++){
                normal[r][c] += row[r] * row[c];
            }
        }
    }

    if(!solve_linear_system(normal, rhs, coef, dim)){
        *Vrms = 0.0f;
        *Vpp = 0.0f;
        return;
    }

    float32_t amp_sq_sum = 0.0f;
    for(uint8_t i = 0U; i < component_count; i++){
        I[i] = coef[1U + 2U * i];
        Q[i] = coef[2U + 2U * i];
        float32_t amp = sqrtf(I[i] * I[i] + Q[i] * Q[i]);
        uint8_t order = order_list[i];
        if(vol_amp_by_order != NULL && order <= VOL_HARMONIC_ORDER_MAX){
            vol_amp_by_order[order] = amp;
        }
        amp_sq_sum += amp * amp;
    }

    float32_t max_v =-1e9f;
    float32_t min_v = 1e9f;

    for(uint16_t k =0U;k < VPP_RECON_SIZE;k++){
        float32_t x = 0.0f;
        float32_t theta = 2.0f * PI * (float32_t)k / (float32_t)VPP_RECON_SIZE;

        for(uint8_t i = 0 ;i < component_count;i++){
            uint8_t order = order_list[i];
            float32_t phase = theta * (float32_t)order;
            x += I[i] * arm_cos_f32(phase) + Q[i] * arm_sin_f32(phase);
        }

        if(x >max_v){max_v = x;}
        if(x<min_v){min_v = x;}
    }

    *Vrms = sqrtf(0.5f * amp_sq_sum);
    *Vpp = max_v-min_v;
    uint16_t x;
    x=0;
    (void)x;

}
