#include "ADC_Sample.h"
#include "ALL_CALC.h"
#include "FFT.h"
#include "FPGA_CTRL.h"
#include "Vol_calc.h"
#include "app_main.h"
#include "arm_math_types.h"
#include "stm32_hal_legacy.h"
#include <math.h>
#include <stdint.h>



void all_calc(volatile uint8_t ready_flag,
              uint8_t* calc_count,
              float32_t* Vrms,
              float32_t* Vpp,
              float32_t vol_component_amp[][VOL_AMP_BY_ORDER_SIZE],
              float32_t* Vrms_mean,
              float32_t* Vpp_mean,
              float32_t* vol_amp,
              uint8_t* vol_amp_valid_count)
{
    if(ready_flag == 1U && *calc_count < Calc_Count_MAX){
        ADC_Stop();
        fft_calc();
        calc_Vol(&Vrms[*calc_count], &Vpp[*calc_count], vol_component_amp[*calc_count]);
        (*calc_count)++;
        if(*calc_count < Calc_Count_MAX){
            FPGA_Start();
        }
    }

    if(*calc_count == Calc_Count_MAX){
        *calc_count = 0U;
        float32_t sum_Vrms = 0.0f;
        float32_t sum_Vpp = 0.0f;
        for(uint8_t i = 0;i<Calc_Count_MAX;i++){
            sum_Vrms += Vrms[i];
            sum_Vpp += Vpp[i];
        }
        *Vrms_mean = sum_Vrms/(float32_t)Calc_Count_MAX;
        *Vpp_mean = sum_Vpp/(float32_t)Calc_Count_MAX;

        vol_amp[0] = 0.0f;
        vol_amp_valid_count[0] = 0U;

        for(uint8_t i = 1U ; i < VOL_AMP_BY_ORDER_SIZE ; i++){
            float32_t sum_amp = 0.0f;
            uint8_t valid_count = 0U;
            for(uint8_t j = 0 ; j<Calc_Count_MAX;j++){
                if(vol_component_amp[j][i] > 0.0f){
                    sum_amp += vol_component_amp[j][i];
                    valid_count++;
                }
            }

            vol_amp_valid_count[i] = valid_count;
            if(valid_count > 0U){
                vol_amp[i ] = sum_amp / (float32_t)valid_count;
            }else{
                vol_amp[i]=0.0f;
            }
        }

        uint8_t x= 0;
        (void)x;
    }
}
