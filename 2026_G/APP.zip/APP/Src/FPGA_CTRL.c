#include "FPGA_CTRL.h"
#include "main.h"
#include "stm32g4xx_hal.h"
#include "stm32g4xx_hal_def.h"
#include "stm32g4xx_hal_gpio.h"
#include "stm32g4xx_hal_spi.h"
#include <stdint.h>
#include "spi.h"

int16_t FPGA_buffer[N];

void FPGA_RESET(void){
    HAL_GPIO_WritePin(FPGA_RSTN_GPIO_Port, FPGA_RSTN_Pin,GPIO_PIN_RESET);
    HAL_Delay(10);
    HAL_GPIO_WritePin(FPGA_RSTN_GPIO_Port,FPGA_RSTN_Pin,GPIO_PIN_SET);
    HAL_Delay(10);
}


void FPGA_Start(void){
    uint8_t tx_buffer[4];


    tx_buffer[0]=0x07;
    tx_buffer[1] = B;

    if(HAL_SPI_Transmit(&hspi1,tx_buffer, 2, 1000)!=HAL_OK){
        Error_Handler();
    }
}

void FPGA_Get_sample(uint8_t ready_flag){
    uint8_t rx_buffer[8193];
    if(ready_flag == 1U){
        if(HAL_SPI_Receive(&hspi1,rx_buffer,2*N+1,5000) != HAL_OK||rx_buffer[2*N] != 0x21){
            Error_Handler();
        }
        for(uint32_t i = 0U; i< N ; i++){
            uint8_t hdata = rx_buffer[2U*i+0U];
            uint8_t ldata = rx_buffer[2U*i+1U];
            uint16_t data = (((uint16_t)hdata) << 8) | ldata;
            FPGA_buffer[i] = *(int16_t *)&data;
        }
    }
}