#include "app_main.h"
#include "ADC_Sample.h"
#include "FFT.h"
#include "FPGA_CTRL.h"
#include "adc.h"
#include "arm_math_types.h"
#include "main.h"
#include "stm32g4xx_hal.h"
#include "stm32g4xx_hal_adc.h"
#include "stm32g4xx_hal_adc_ex.h"
#include "stm32g4xx_hal_gpio.h"
#include "stm32g4xx_hal_tim.h"
#include "stm32g4xx_hal_uart.h"
#include "tim.h"
#include "usart.h"
#include <math.h>
#include <stdint.h>
#include "Vol_calc.h"
#include "ALL_CALC.h"


static volatile uint8_t adc_frame_ready = 0U;
static volatile uint8_t FPGA_data_ready = 0U;
float32_t Vrms[Calc_Count_MAX];
float32_t Vpp[Calc_Count_MAX];
float32_t Vrms_mean=0.0f;
float32_t Vpp_mean = 0.0f;

float32_t vol_component_amp[Calc_Count_MAX][VOL_AMP_BY_ORDER_SIZE];
float32_t vol_amp[VOL_AMP_BY_ORDER_SIZE] = {0.0f};
uint8_t vol_amp_valid_count[VOL_AMP_BY_ORDER_SIZE] = {0U};

void app_main(void)
{
    HAL_Delay(100);
    FPGA_RESET();
    FPGA_Start();
    ADC_Start();
    uint8_t calc_count = 0;

    while (1) {
        while(!FPGA_data_ready){}
        FPGA_Get_sample(FPGA_data_ready);
        if(calc_count == 0){
            HAL_UART_Transmit(&huart5, (const uint8_t* )FPGA_buffer, sizeof(FPGA_buffer), 5000);
        }
        all_calc(adc_frame_ready, &calc_count, Vrms, Vpp, vol_component_amp, &Vrms_mean, &Vpp_mean, vol_amp,vol_amp_valid_count);

        if(adc_frame_ready == 1U){
            adc_frame_ready = 0U;
        }
    }
}

// void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
// {
//     if (hadc->Instance == ADC1) {
//         adc_frame_ready = 1U;
//     }
// }

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin){
    if(GPIO_Pin == FPGA_IRQN_Pin){
        FPGA_data_ready = 1U;
    }
}