#ifndef __ALL_CALC_H__
#define __ALL_CALC_H__

#include "app_main.h"
#include "Vol_calc.h"
#include <stdint.h>

void all_calc(volatile uint8_t ready_flag,
              uint8_t* calc_count,
              float32_t* Vrms,
              float32_t* Vpp,
              float32_t vol_component_amp[][VOL_AMP_BY_ORDER_SIZE],
              float32_t* Vrms_mean,
              float32_t* Vpp_mean,
              float32_t* vol_amp,
              uint8_t* vol_amp_valid_count);

#endif
