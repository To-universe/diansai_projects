#ifndef __ADC_SAMPLE_H__
#define __ADC_SAMPLE_H__

#include "app_main.h"
#include <stdint.h>

#define ADC_SIZE ADC_SAMPLE_COUNT
#define FS 2047812.5f


extern uint16_t adc_buffer[ADC_SIZE];

void ADC_Start(void);
void ADC_Stop(void);

#endif