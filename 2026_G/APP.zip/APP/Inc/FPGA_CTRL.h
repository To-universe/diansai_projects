#ifndef __FPGA_CTRL_H__
#define __FPGA_CTRL_H__

#include "app_main.h"
#include <stdint.h>

#define B 12
#define N ADC_SAMPLE_COUNT

extern int16_t FPGA_buffer[N];

void FPGA_RESET(void);
void FPGA_Start(void);
void FPGA_Get_sample(uint8_t ready_flag);

#endif