#ifndef __APP_MAIN_H__
#define __APP_MAIN_H__

#include "main.h"

#define Calc_Count_MAX 5
#define ADC_SAMPLE_COUNT 4096U

void app_main(void);

#endif
