#ifndef __VOL_CALC_H__
#define __VOL_CALC_H__


#include "app_main.h"
#include "arm_math_types.h"
#include "FFT.h"

#define METRIC_SIZE 4000
#define ADC_VREF 3.3f
#define ADC_FULL_SCALE 4095.0f
#define INPUT_SCALE 1.0f
#define VOL_COMPONENT_MAX PEAK_MAX_COUNT
#define VOL_HARMONIC_ORDER_MAX 20U
#define VOL_AMP_BY_ORDER_SIZE (VOL_HARMONIC_ORDER_MAX + 1U)

float32_t calc_vrms(void);
float32_t calc_vpp(void);
void calc_Vol(float32_t* Vrms,float32_t* Vpp,float32_t* vol_amp_by_order);

#endif
