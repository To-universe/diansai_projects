#ifndef __FFT_H__
#define __FFT_H__

#include "app_main.h"
#include "ADC_Sample.h"
#include "arm_math.h"

#define FFT_SIZE ADC_SIZE
#define BIN_MIN 18U
#define BIN_MAX 1027U

#define PEAK_MAX_COUNT 3U

#define FREQ_GRID_HZ 500.0f
#define G_MIN 20
#define G_MAX 1000
#define FUND_SEARCH_RADIUS 2

extern arm_rfft_instance_q15 fft_instance;
extern q15_t fft_input[FFT_SIZE];
extern q15_t fft_output[FFT_SIZE * 2];
extern float32_t magnitude[FFT_SIZE/2];
extern float32_t noise_lim;
extern uint16_t peak_bin[3];
extern uint8_t peak_count;
extern float32_t peak_bin_freq[PEAK_MAX_COUNT];
extern float32_t peak_interp_freq[PEAK_MAX_COUNT];

extern float32_t fitted_f0;
extern float32_t measured_f0;
extern uint8_t peak_harmonic_order[PEAK_MAX_COUNT];
extern float32_t fitted_peak_freq[PEAK_MAX_COUNT];

void adc_to_q15(uint16_t * adc_data,q15_t * fft_data);
void get_mag(void);
void get_noise_lim(void);
void find_peak_bin(void);
void fft_calc(void);

#endif
