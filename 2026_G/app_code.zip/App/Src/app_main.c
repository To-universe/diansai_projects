#include "app_main.h"
#include "calc.h"
#include "fft.h"
#include "fpga.h"
#include "voltage.h"
#include "main.h"
#include "stm32g4xx_hal.h"
#include "stm32g4xx_hal_gpio.h"
#include <stdbool.h>
#include <stdio.h>

typedef enum {
    STATE_IDLE,
    STATE_MEASURE,
    STATE_DISPLAY,
    STATE_SCREEN_TIME,
    STATE_SCREEN_FREQ,
} app_state_t;

typedef struct {
    app_state_t state;
    calc_accumulator_t acc;
    bool display_ready;
    float32_t vrms_mean;
    float32_t vpp_mean;
    float32_t f0;
    float32_t harmonic_means[VOL_AMP_BY_ORDER_SIZE];
    uint8_t  valid_counts[VOL_AMP_BY_ORDER_SIZE];
    float32_t waveform[WAVEFORM_SIZE];
} app_ctx_t;

/* newlib-nano drops %f support; use this instead */
static void print_f32(float32_t v, uint8_t int_width, uint8_t frac_digits)
{
    if (v < 0.0f) {
        printf("-");
        v = -v;
    }
    int32_t ipart = (int32_t)v;
    float32_t frac = v - (float32_t)ipart;
    uint32_t scale = 1U;
    for (uint8_t d = 0U; d < frac_digits; d++) {
        scale *= 10U;
    }
    uint32_t fpart = (uint32_t)(frac * (float32_t)scale + 0.5f);
    if (fpart >= scale) {
        ipart++;
        fpart -= scale;
    }
    printf("%*ld.%0*lu", int_width, (long)ipart, frac_digits, (unsigned long)fpart);
}

static void process_input(app_ctx_t *ctx)
{
    /*
     * TODO  UART-HMI integration:
     * Read UART RX buffer, parse HMI command frames.
     *
     * Commands:
     *   CMD_START_MEASURE  -> ctx->state = STATE_MEASURE
     *   CMD_SCREEN_TIME    -> ctx->state = STATE_SCREEN_TIME
     *   CMD_SCREEN_FREQ    -> ctx->state = STATE_SCREEN_FREQ
     */

    /* auto-trigger measurement when idle (placeholder until HMI is wired) */
    if (ctx->state == STATE_IDLE) {
        ctx->state = STATE_MEASURE;
    }
}

static void state_calculation(app_ctx_t *ctx)
{
    if (ctx->state != STATE_MEASURE) {
        return;
    }

    for (uint8_t i = 0U; i < CALC_FRAME_COUNT; i++) {
        fpga_start_capture();

        while (!fpga_is_data_ready()) {}
        if (!fpga_receive()) {
            Error_Handler();
        }

        // const int16_t *buffer = fpga_get_buffer();
        // for (uint32_t i = 0; i < 4096; i++) {
        //     float value = (float32_t)buffer[i] / (float32_t)(1UL << 15);
        //     print_f32(value, 1, 2);
        //     printf("%c", i % 16 == 15 ? '\n' : ' ');
        // }

        HAL_Delay(100);

        fft_result_t fft_res;
        fft_compute(fpga_get_buffer(), &fft_res);

        printf("[frame %u] peaks=%u  f0=", i, fft_res.peak_count);
        print_f32(fft_res.fitted_f0, 0, 1);
        printf(" Hz  noise_floor=");
        print_f32(fft_res.noise_floor, 0, 1);
        printf("\r\n");

        vol_result_t vol_res;
        voltage_compute(fpga_get_buffer(), &fft_res, &vol_res);

        calc_accumulate(&ctx->acc, &vol_res);
    }

    float32_t f0_mean;
    float32_t waveform_mean[WAVEFORM_SIZE];

    calc_finalize(&ctx->acc,
                  &ctx->vrms_mean, &ctx->vpp_mean, &f0_mean,
                  ctx->harmonic_means, ctx->valid_counts,
                  waveform_mean);

    ctx->f0 = f0_mean;
    for (uint16_t k = 0U; k < WAVEFORM_SIZE; k++) {
        ctx->waveform[k] = waveform_mean[k];
    }

    ctx->display_ready = true;

    calc_init(&ctx->acc);
    ctx->state = STATE_DISPLAY;
}

static void show(app_ctx_t *ctx)
{
    if (!ctx->display_ready) {
        return;
    }

    printf("=== Results ===\r\n\r\n");

    printf("Vrms       : ");
    print_f32(ctx->vrms_mean, 0, 4);
    printf(" V\r\n");

    printf("Vpp        : ");
    print_f32(ctx->vpp_mean, 0, 4);
    printf(" V\r\n");

    printf("Fundamental: ");
    print_f32(ctx->f0, 0, 2);
    printf(" Hz\r\n");

    printf("\r\nHarmonics:\r\n");
    for (uint8_t i = 1U; i < VOL_AMP_BY_ORDER_SIZE; i++) {
        if (ctx->valid_counts[i] > 0U) {
            printf("  H%-2u : ", i);
            print_f32((float32_t)i * ctx->f0, 8, 2);
            printf(" Hz  ");
            print_f32(ctx->harmonic_means[i], 8, 4);
            printf(" V  (valid %u/%u)\r\n",
                   ctx->valid_counts[i], (unsigned)CALC_FRAME_COUNT);
        }
    }

    printf("\r\nWaveform (256 pts):\r\n  ");
    for (uint16_t k = 0U; k < WAVEFORM_SIZE; k++) {
        print_f32(ctx->waveform[k], 0, 3);
        if (k < WAVEFORM_SIZE - 1U) {
            printf(",");
        }
        if ((k & 7U) == 7U && k < WAVEFORM_SIZE - 1U) {
            printf("\r\n  ");
        }
    }
    printf("\r\n\r\n");

    ctx->display_ready = false;

    /* return to idle so process_input can re-trigger */
    ctx->state = STATE_IDLE;
}

void app_main(void)
{
    HAL_Delay(100);
    fpga_reset();
    fft_init();

    app_ctx_t ctx = {0};
    ctx.state = STATE_IDLE;
    calc_init(&ctx.acc);

    while (1) {
        process_input(&ctx);
        state_calculation(&ctx);
        show(&ctx);
        HAL_Delay(1000);
    }
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    if (GPIO_Pin == FPGA_IRQN_Pin) {
        fpga_signal_data_ready();
    }
}
