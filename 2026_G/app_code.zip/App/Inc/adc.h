#ifndef __ADC_H__
#define __ADC_H__

#include <stdint.h>

#define ADC_SIZE        4096U
#define FS              2047812.5f

extern uint16_t adc_buffer[ADC_SIZE];

void adc_signal_frame_ready(void);
uint8_t adc_is_frame_ready(void);
void adc_clear_frame_ready(void);
const uint16_t* adc_get_buffer(void);

#endif
